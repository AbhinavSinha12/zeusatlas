/*
 * Copyright (c) 2004 Christopher Lenz and others
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     Christopher Lenz - initial implementation
 * 
 * $Id: IBrowserPreviewPage.java,v 1.1 2004/02/18 16:54:17 cell Exp $
 */

package net.sf.wdte.ui.views.preview;

import org.eclipse.ui.part.IPage;

/**
 * 
 */
public interface IBrowserPreviewPage extends IPage {

}
